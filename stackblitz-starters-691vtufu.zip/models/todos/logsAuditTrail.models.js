import mongoose from "mongoose";


const LogSchema = new mongoose.Schema(
  {
     userId: {
         type: mongoose.Schema.Types.ObjectId,
         ref: 'User'
     },
     action: String,
     details: String,
     generatedAt: {
       type: Date,
       default: Date.now
     }
  }, { timestamps: true}
);

export const Log = mongoose.model("Log", LogSchema)