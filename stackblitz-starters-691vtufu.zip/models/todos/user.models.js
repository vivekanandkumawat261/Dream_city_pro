 import mongoose from "mongoose"

// const mongoose = require('mongoose')
  
const userSchema = new mongoose.Schema(
    {
      email: {
          type: String,
          required: true,
          unique: true,
      },
      password: {           
        type: String,              
        required: true                  
      },
      name: String,
      createdAt: {
        type: Date,
        default: Date.now
      },
      favorites: [{
        type:mongoose.Schema.Type.ObjectId,
        ref: 'City'
      }],
      recentlyViewed: [{
        cityId: {
          type: mongoose.Schema.Types.ObjectId,
          ref: 'City'
        },
        viewedAt: {
          type: Date,
          default: Date.now
        }
        }],
        role: {
           type: String,
           enum: ['user','admin'],
           default: 'user'
        }
    }, {timestamps: true}
);

export const User = mongoose.model("User", userSchema)